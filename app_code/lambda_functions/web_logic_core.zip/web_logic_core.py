def lambda_handler(event, context):
    """
    A simple AWS Lambda function placeholder.
    """
    return {
        'statusCode': 200,
        'body': 'Hello from Lambda!'
    }